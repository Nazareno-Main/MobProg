# SmileCare Dental – appointment app

A React Native (Expo) app for booking and managing dental appointments, with accounts and full appearance customisation. Everything is stored on the device, so it works offline with no backend.

## Features

- **Accounts** – register, log in, stay signed in, edit profile, change password, reset password, delete account. Passwords are salted and SHA-256 hashed before being stored.
- **Booking** – pick a service, a dentist who offers it, a date (next 14 days, closed Sundays) and an open time slot. Taken and past slots are disabled. Add optional notes.
- **My appointments** – Upcoming / Past / Cancelled tabs, reschedule and cancel with confirmation.
- **Home dashboard** – greeting, next appointment, quick actions, daily dental tip, popular services, clinic info (tap to call).
- **Customisation** (Profile → Appearance & settings)
  - Theme: System / Light / Dark
  - Accent colour: Teal, Ocean, Violet, Rose, Sunset
  - Text size: Small / Medium / Large
  - Saved between launches

## Run it

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go, or press `a` / `i` / `w` for Android, iOS or web.

**Demo logins:** `admin@demo.com` / `admin123` · `manager@demo.com` / `manager123`

## Make it your clinic's

Edit `src/data/clinic.js`: clinic name, phone, address, hours, services, prices, dentists and time slots. All screens read from it.

## Project structure

```
App.js                      providers (theme → auth → appointments) + navigator
src/context/                ThemeContext, AuthContext, AppointmentsContext
src/navigation/             auth stack, bottom tabs, modal-style stack screens
src/screens/                Login, Register, ForgotPassword, Home, Appointments,
                            Book, Services, Profile, Settings, EditProfile, ChangePassword
src/components/             AppButton, InputField, BrandHeader, AppointmentCard, ui.js
src/theme/theme.js          colours, accents, text scale
src/data/clinic.js          clinic info, services, dentists, tips
src/utils/                  date helpers, AsyncStorage wrapper
```

## Notes / limitations

- Data lives in AsyncStorage on one device. Accounts and bookings are not shared between phones; a real deployment needs a backend (e.g. Firebase or Supabase).
- "Forgot password" resets on-device because there is no email service.
- Prices and clinic details are placeholders.
