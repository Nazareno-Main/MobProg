import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';
import { useStyles, useTheme } from '../context/ThemeContext';

export default function BrandHeader({ title, subtitle }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  return (
    <View style={styles.wrapper}>
      <View style={styles.logo}>
        <FontAwesome5 name="tooth" size={30} color={colors.white} />
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
    </View>
  );
}

const makeStyles = ({ colors, typography, radius, spacing }) =>
  StyleSheet.create({
    wrapper: { alignItems: 'center', marginBottom: spacing.xl },
    logo: {
      width: 64,
      height: 64,
      borderRadius: radius.pill,
      backgroundColor: colors.primary,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: spacing.md,
    },
    title: { ...typography.h1, marginBottom: spacing.xs },
    subtitle: { ...typography.body, color: colors.textMuted, textAlign: 'center' },
  });
