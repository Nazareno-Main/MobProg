import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, View } from 'react-native';
import { useStyles, useTheme } from '../context/ThemeContext';

export default function AppButton({
  title,
  onPress,
  variant = 'primary', // primary | outline | text | danger
  loading = false,
  disabled = false,
  icon = null,
  style,
}) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  const isDisabled = disabled || loading;
  const filled = variant === 'primary' || variant === 'danger';

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      style={[styles.base, styles[variant], isDisabled && styles.disabled, style]}
    >
      {loading ? (
        <ActivityIndicator color={filled ? colors.white : colors.primary} />
      ) : (
        <View style={styles.content}>
          {icon}
          <Text style={[styles.label, styles[`${variant}Label`]]}>{title}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const makeStyles = ({ colors, typography, radius, spacing }) =>
  StyleSheet.create({
    base: { height: 52, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.lg },
    content: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    primary: {
      backgroundColor: colors.primary,
      shadowColor: colors.primary,
      shadowOpacity: 0.25,
      shadowOffset: { width: 0, height: 6 },
      shadowRadius: 10,
      elevation: 3,
    },
    danger: { backgroundColor: colors.danger },
    outline: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: colors.primary },
    text: { backgroundColor: 'transparent', height: 'auto', paddingVertical: spacing.xs },
    disabled: { opacity: 0.5 },
    label: { ...typography.button },
    primaryLabel: { color: colors.white },
    dangerLabel: { color: colors.white },
    outlineLabel: { color: colors.primary },
    textLabel: { color: colors.primary },
  });
