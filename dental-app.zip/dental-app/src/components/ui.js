// Small themed building blocks shared by every screen.
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useStyles, useTheme } from '../context/ThemeContext';

export function Screen({ children, scroll = true, edges = ['top'], contentStyle, style }) {
  const styles = useStyles(makeStyles);
  const body = scroll ? (
    <ScrollView contentContainerStyle={[styles.content, contentStyle]} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  ) : (
    <View style={[styles.content, { flex: 1 }, contentStyle]}>{children}</View>
  );
  return (
    <SafeAreaView edges={edges} style={[styles.screen, style]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {body}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export function Header({ title, onBack, right }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  return (
    <View style={styles.header}>
      {onBack ? (
        <TouchableOpacity onPress={onBack} style={styles.backBtn} hitSlop={10} accessibilityLabel="Go back">
          <Ionicons name="arrow-back" size={22} color={colors.secondary} />
        </TouchableOpacity>
      ) : null}
      <Text style={styles.headerTitle} numberOfLines={1}>{title}</Text>
      {right}
    </View>
  );
}

export function Card({ children, style, onPress }) {
  const styles = useStyles(makeStyles);
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper activeOpacity={0.8} onPress={onPress} style={[styles.card, style]}>
      {children}
    </Wrapper>
  );
}

export function SectionTitle({ children, action, onAction }) {
  const styles = useStyles(makeStyles);
  return (
    <View style={styles.sectionRow}>
      <Text style={styles.sectionTitle}>{children}</Text>
      {action ? (
        <TouchableOpacity onPress={onAction}>
          <Text style={styles.sectionAction}>{action}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

export function Avatar({ user, size = 44 }) {
  const styles = useStyles(makeStyles);
  const initials = `${user?.firstName?.[0] || ''}${user?.lastName?.[0] || ''}`.toUpperCase() || '?';
  return (
    <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2 }]}>
      <Text style={[styles.avatarText, { fontSize: size * 0.38 }]}>{initials}</Text>
    </View>
  );
}

export function Chip({ label, selected, onPress, icon, disabled }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.8}
      style={[styles.chip, selected && styles.chipSelected, disabled && { opacity: 0.4 }]}
    >
      {icon ? <Ionicons name={icon} size={16} color={selected ? colors.white : colors.primary} /> : null}
      <Text style={[styles.chipText, selected && styles.chipTextSelected, disabled && { textDecorationLine: 'line-through' }]}>{label}</Text>
    </TouchableOpacity>
  );
}

export function Segmented({ options, value, onChange }) {
  const styles = useStyles(makeStyles);
  return (
    <View style={styles.segmented}>
      {options.map((o) => (
        <TouchableOpacity key={o.value} style={[styles.segment, value === o.value && styles.segmentActive]} onPress={() => onChange(o.value)}>
          <Text style={[styles.segmentText, value === o.value && styles.segmentTextActive]}>{o.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

export function Row({ icon, label, value, onPress, danger, last }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  const tint = danger ? colors.danger : colors.primary;
  return (
    <TouchableOpacity onPress={onPress} disabled={!onPress} activeOpacity={0.7} style={[styles.menuRow, !last && styles.menuRowBorder]}>
      <View style={[styles.menuIcon, { backgroundColor: danger ? `${colors.danger}22` : colors.primaryLight }]}>
        <Ionicons name={icon} size={18} color={tint} />
      </View>
      <Text style={[styles.menuLabel, danger && { color: colors.danger }]}>{label}</Text>
      {value ? <Text style={styles.menuValue}>{value}</Text> : null}
      {onPress && !danger ? <Ionicons name="chevron-forward" size={18} color={colors.placeholder} /> : null}
    </TouchableOpacity>
  );
}

export function EmptyState({ icon, title, message, children }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  return (
    <View style={styles.empty}>
      <Ionicons name={icon} size={56} color={colors.primary} />
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyMsg}>{message}</Text>
      {children}
    </View>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.background },
    content: { padding: spacing.lg, paddingBottom: spacing.xxl },
    header: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.lg },
    backBtn: { marginRight: spacing.md },
    headerTitle: { ...typography.h1, flex: 1 },
    card: {
      backgroundColor: colors.card,
      borderRadius: radius.lg,
      borderWidth: 1,
      borderColor: colors.border,
      padding: spacing.md,
      marginBottom: spacing.md,
    },
    sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: spacing.sm, marginBottom: spacing.md },
    sectionTitle: { ...typography.h2 },
    sectionAction: { color: colors.primary, fontWeight: '600', fontSize: fs(14) },
    avatar: { backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
    avatarText: { color: colors.white, fontWeight: '700' },
    chip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingVertical: 10,
      paddingHorizontal: 14,
      borderRadius: radius.pill,
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.card,
    },
    chipSelected: { backgroundColor: colors.primary, borderColor: colors.primary },
    chipText: { color: colors.text, fontSize: fs(14), fontWeight: '600' },
    chipTextSelected: { color: colors.white },
    segmented: { flexDirection: 'row', backgroundColor: colors.surface, borderRadius: radius.md, padding: 4, borderWidth: 1, borderColor: colors.border },
    segment: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: radius.sm },
    segmentActive: { backgroundColor: colors.primary },
    segmentText: { color: colors.textMuted, fontWeight: '600', fontSize: fs(14) },
    segmentTextActive: { color: colors.white },
    menuRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14 },
    menuRowBorder: { borderBottomWidth: 1, borderBottomColor: colors.border },
    menuIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: spacing.md },
    menuLabel: { ...typography.body, flex: 1 },
    menuValue: { ...typography.caption, marginRight: spacing.sm },
    empty: { alignItems: 'center', paddingVertical: spacing.xl, paddingHorizontal: spacing.lg },
    emptyTitle: { ...typography.h2, marginTop: spacing.md },
    emptyMsg: { ...typography.body, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xs, marginBottom: spacing.lg },
  });
