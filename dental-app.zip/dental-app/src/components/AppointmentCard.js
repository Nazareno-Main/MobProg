import React from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card } from './ui';
import AppButton from './AppButton';
import { useStyles, useTheme } from '../context/ThemeContext';
import { getDentist, getService } from '../data/clinic';
import { formatDate, formatTime } from '../utils/date';

export default function AppointmentCard({ appt, onReschedule, onCancel, compact }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  const service = getService(appt.serviceId);
  const dentist = getDentist(appt.dentistId);
  const cancelled = appt.status === 'cancelled';
  const actionable = !compact && !cancelled && (onReschedule || onCancel);

  const confirmCancel = () =>
    Alert.alert('Cancel appointment?', `${service.name} on ${formatDate(appt.date)} at ${formatTime(appt.time)}.`, [
      { text: 'Keep it', style: 'cancel' },
      { text: 'Cancel appointment', style: 'destructive', onPress: () => onCancel(appt) },
    ]);

  return (
    <Card>
      <View style={styles.top}>
        <View style={styles.icon}>
          <Ionicons name={service.icon} size={22} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{service.name}</Text>
          <Text style={styles.sub}>{dentist.name}</Text>
        </View>
        {cancelled ? <Text style={styles.badge}>Cancelled</Text> : null}
      </View>
      <View style={styles.meta}>
        <View style={styles.metaItem}>
          <Ionicons name="calendar-outline" size={16} color={colors.textMuted} />
          <Text style={styles.metaText}>{formatDate(appt.date)}</Text>
        </View>
        <View style={styles.metaItem}>
          <Ionicons name="time-outline" size={16} color={colors.textMuted} />
          <Text style={styles.metaText}>{formatTime(appt.time)}</Text>
        </View>
      </View>
      {appt.notes ? <Text style={styles.notes}>“{appt.notes}”</Text> : null}
      {actionable ? (
        <View style={styles.actions}>
          {onReschedule ? <AppButton title="Reschedule" variant="outline" onPress={() => onReschedule(appt)} style={styles.actionBtn} /> : null}
          {onCancel ? <AppButton title="Cancel" variant="text" onPress={confirmCancel} style={styles.cancelBtn} /> : null}
        </View>
      ) : null}
    </Card>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    top: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
    icon: { width: 44, height: 44, borderRadius: radius.md, backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center' },
    title: { ...typography.h3 },
    sub: { ...typography.caption },
    badge: { color: colors.danger, fontWeight: '700', fontSize: fs(12) },
    meta: { flexDirection: 'row', gap: spacing.lg, marginTop: spacing.md },
    metaItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    metaText: { ...typography.body, fontWeight: '500' },
    notes: { ...typography.caption, marginTop: spacing.sm, fontStyle: 'italic' },
    actions: { flexDirection: 'row', alignItems: 'center', marginTop: spacing.md, gap: spacing.sm },
    actionBtn: { flex: 1, height: 44 },
    cancelBtn: { paddingHorizontal: spacing.md },
  });
