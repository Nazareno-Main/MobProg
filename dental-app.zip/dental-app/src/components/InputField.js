import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStyles, useTheme } from '../context/ThemeContext';

export default function InputField({ label, icon, error, isPassword = false, style, multiline, ...inputProps }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  const [secure, setSecure] = useState(isPassword);
  const [focused, setFocused] = useState(false);

  return (
    <View style={[styles.wrapper, style]}>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <View style={[styles.row, multiline && styles.multiline, focused && styles.focused, error && styles.error]}>
        {icon ? (
          <Ionicons name={icon} size={20} color={focused ? colors.primary : colors.placeholder} style={styles.icon} />
        ) : null}
        <TextInput
          style={[styles.input, multiline && { textAlignVertical: 'top', paddingTop: 14 }]}
          placeholderTextColor={colors.placeholder}
          secureTextEntry={secure}
          multiline={multiline}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          {...inputProps}
        />
        {isPassword ? (
          <TouchableOpacity onPress={() => setSecure((s) => !s)} hitSlop={10}>
            <Ionicons name={secure ? 'eye-off-outline' : 'eye-outline'} size={20} color={colors.placeholder} />
          </TouchableOpacity>
        ) : null}
      </View>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    wrapper: { marginBottom: spacing.md },
    label: { ...typography.caption, color: colors.secondary, marginBottom: spacing.xs, fontWeight: '600' },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      borderWidth: 1.5,
      borderColor: colors.border,
      borderRadius: radius.md,
      backgroundColor: colors.surface,
      paddingHorizontal: spacing.md,
      minHeight: 52,
    },
    multiline: { minHeight: 96, alignItems: 'flex-start' },
    focused: { borderColor: colors.primary, backgroundColor: colors.card },
    error: { borderColor: colors.danger },
    icon: { marginRight: spacing.sm },
    input: { flex: 1, fontSize: fs(15), color: colors.text, paddingVertical: 12 },
    errorText: { color: colors.danger, fontSize: fs(12), marginTop: spacing.xs },
  });
