// Edit this file to rebrand the app for your own clinic.
export const CLINIC = {
  name: 'SmileCare Dental',
  phone: '+639170000000',
  phoneLabel: '+63 917 000 0000',
  address: '123 Rizal Avenue, Manila, Philippines',
  hours: 'Mon–Sat, 9:00 AM – 5:00 PM',
};

export const SERVICES = [
  { id: 'checkup', name: 'Check-up & Cleaning', icon: 'happy-outline', minutes: 30, price: 800, about: 'Full oral exam, scaling and polishing.' },
  { id: 'whitening', name: 'Teeth Whitening', icon: 'sparkles-outline', minutes: 60, price: 3500, about: 'In-clinic whitening for a brighter smile.' },
  { id: 'filling', name: 'Dental Filling', icon: 'construct-outline', minutes: 45, price: 1200, about: 'Tooth-coloured fillings for cavities.' },
  { id: 'extraction', name: 'Tooth Extraction', icon: 'medkit-outline', minutes: 45, price: 1500, about: 'Simple and surgical extractions.' },
  { id: 'braces', name: 'Braces Consultation', icon: 'shield-checkmark-outline', minutes: 30, price: 500, about: 'Assessment and treatment planning.' },
  { id: 'rootcanal', name: 'Root Canal', icon: 'pulse-outline', minutes: 90, price: 6000, about: 'Relieve pain and save an infected tooth.' },
  { id: 'xray', name: 'Dental X-Ray', icon: 'scan-outline', minutes: 15, price: 600, about: 'Digital panoramic and periapical X-rays.' },
];

export const DENTISTS = [
  { id: 'santos', name: 'Dr. Maria Santos', specialty: 'General Dentistry', serviceIds: ['checkup', 'filling', 'extraction', 'xray'] },
  { id: 'reyes', name: 'Dr. Paolo Reyes', specialty: 'Orthodontics', serviceIds: ['braces', 'checkup', 'xray'] },
  { id: 'cruz', name: 'Dr. Angela Cruz', specialty: 'Endodontics', serviceIds: ['rootcanal', 'xray', 'filling'] },
  { id: 'ramos', name: 'Dr. Miguel Ramos', specialty: 'Cosmetic Dentistry', serviceIds: ['whitening', 'checkup'] },
];

export const TIME_SLOTS = ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00'];

export const TIPS = [
  'Brush for two minutes, twice a day, with fluoride toothpaste.',
  'Floss once a day: it reaches the 40% of tooth surface a brush misses.',
  'Replace your toothbrush every three months, or after an illness.',
  'Limit sugary drinks and snacks; they feed the bacteria that cause cavities.',
  'Wait 30 minutes after acidic food or drinks before brushing.',
  "Don't forget your tongue: brushing it helps keep breath fresh.",
  'Visit your dentist every six months, even if nothing hurts.',
  'Drink water after meals to rinse away food particles.',
];

export const getService = (id) => SERVICES.find((s) => s.id === id);
export const getDentist = (id) => DENTISTS.find((d) => d.id === id);
export const peso = (n) => `₱${n.toLocaleString('en-US')}`;
