import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Header, Segmented, EmptyState } from '../components/ui';
import AppointmentCard from '../components/AppointmentCard';
import AppButton from '../components/AppButton';
import { useAppointments } from '../context/AppointmentsContext';
import { useTheme } from '../context/ThemeContext';

const TABS = [
  { value: 'upcoming', label: 'Upcoming' },
  { value: 'past', label: 'Past' },
  { value: 'cancelled', label: 'Cancelled' },
];

const EMPTY = {
  upcoming: ['calendar-outline', 'Nothing scheduled', 'Book your next visit in a few taps.'],
  past: ['checkmark-done-outline', 'No past visits yet', 'Completed appointments will show up here.'],
  cancelled: ['close-circle-outline', 'No cancelled visits', 'Cancelled appointments will show up here.'],
};

export default function AppointmentsScreen({ navigation }) {
  const { colors } = useTheme();
  const data = useAppointments();
  const [tab, setTab] = useState('upcoming');
  const list = data[tab];
  const [icon, title, message] = EMPTY[tab];

  return (
    <Screen>
      <Header title="Appointments" />
      <View style={{ marginBottom: 16 }}>
        <Segmented options={TABS} value={tab} onChange={setTab} />
      </View>

      {list.length === 0 ? (
        <EmptyState icon={icon} title={title} message={message}>
          {tab === 'upcoming' ? (
            <AppButton title="Book appointment" onPress={() => navigation.navigate('Book', {})} icon={<Ionicons name="add" size={20} color={colors.white} />} />
          ) : null}
        </EmptyState>
      ) : (
        list.map((a) => (
          <AppointmentCard
            key={a.id}
            appt={a}
            onReschedule={tab === 'upcoming' ? (x) => navigation.navigate('Book', { appointmentId: x.id }) : undefined}
            onCancel={tab === 'upcoming' ? (x) => data.cancel(x.id) : undefined}
          />
        ))
      )}

      {tab === 'upcoming' && list.length > 0 ? (
        <AppButton title="Book another" variant="outline" onPress={() => navigation.navigate('Book', {})} />
      ) : null}
    </Screen>
  );
}
