import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BrandHeader from '../components/BrandHeader';
import InputField from '../components/InputField';
import AppButton from '../components/AppButton';
import { Screen } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useStyles, useTheme } from '../context/ThemeContext';

export default function RegisterScreen({ navigation }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  const { register } = useAuth();
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '', confirmPassword: '' });
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const set = (key) => (value) => setForm((f) => ({ ...f, [key]: value }));

  const handleRegister = async () => {
    const next = {};
    if (!form.firstName.trim()) next.firstName = 'First name is required';
    if (!form.lastName.trim()) next.lastName = 'Last name is required';
    if (!form.email.trim()) next.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) next.email = 'Enter a valid email';
    if (!form.phone.trim()) next.phone = 'Phone number is required';
    if (!form.password) next.password = 'Password is required';
    else if (form.password.length < 6) next.password = 'At least 6 characters';
    if (form.confirmPassword !== form.password) next.confirmPassword = 'Passwords do not match';
    if (!agreed) next.terms = 'Please accept the Terms to continue';
    setErrors(next);
    if (Object.keys(next).length) return;

    setLoading(true);
    const res = await register(form);
    setLoading(false);
    if (!res.ok) setErrors({ [res.field || 'email']: res.error });
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <BrandHeader title="Create Account" subtitle="Book and manage your dental visits with ease" />

      <InputField label="First Name" icon="person-outline" placeholder="Juan" value={form.firstName} onChangeText={set('firstName')} error={errors.firstName} />
      <InputField label="Last Name" icon="person-outline" placeholder="Dela Cruz" value={form.lastName} onChangeText={set('lastName')} error={errors.lastName} />
      <InputField label="Email" icon="mail-outline" placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} value={form.email} onChangeText={set('email')} error={errors.email} />
      <InputField label="Phone Number" icon="call-outline" placeholder="09XX XXX XXXX" keyboardType="phone-pad" value={form.phone} onChangeText={set('phone')} error={errors.phone} />
      <InputField label="Password" icon="lock-closed-outline" placeholder="At least 6 characters" isPassword value={form.password} onChangeText={set('password')} error={errors.password} />
      <InputField label="Confirm Password" icon="lock-closed-outline" placeholder="Re-enter your password" isPassword value={form.confirmPassword} onChangeText={set('confirmPassword')} error={errors.confirmPassword} />

      <TouchableOpacity style={styles.terms} onPress={() => setAgreed((a) => !a)} activeOpacity={0.7}>
        <View style={[styles.checkbox, agreed && styles.checkboxOn]}>
          {agreed && <Ionicons name="checkmark" size={14} color={colors.white} />}
        </View>
        <Text style={styles.termsText}>
          I agree to the <Text style={styles.link}>Terms of Service</Text> and <Text style={styles.link}>Privacy Policy</Text>
        </Text>
      </TouchableOpacity>
      {errors.terms ? <Text style={styles.error}>{errors.terms}</Text> : null}

      <AppButton title="Create Account" onPress={handleRegister} loading={loading} style={{ marginTop: 16 }} />

      <View style={styles.footer}>
        <Text style={styles.footerText}>Already have an account? </Text>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.footerLink}>Log In</Text>
        </TouchableOpacity>
      </View>
    </Screen>
  );
}

const makeStyles = ({ colors, typography, spacing, radius, fs }) =>
  StyleSheet.create({
    terms: { flexDirection: 'row', alignItems: 'flex-start', marginTop: spacing.xs },
    checkbox: { width: 20, height: 20, borderRadius: 6, borderWidth: 1.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', marginRight: spacing.sm, marginTop: 2 },
    checkboxOn: { backgroundColor: colors.primary, borderColor: colors.primary },
    termsText: { ...typography.caption, flex: 1, lineHeight: fs(18) },
    link: { color: colors.primary, fontWeight: '600' },
    error: { color: colors.danger, fontSize: fs(12), marginTop: spacing.xs, marginLeft: 28 },
    footer: { flexDirection: 'row', justifyContent: 'center', marginTop: spacing.lg },
    footerText: { ...typography.body, color: colors.textMuted },
    footerLink: { ...typography.body, color: colors.primary, fontWeight: '700' },
  });
