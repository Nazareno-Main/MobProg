import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Header, Card, SectionTitle, Segmented, Row } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useAppointments } from '../context/AppointmentsContext';
import { useStyles, useTheme } from '../context/ThemeContext';
import { ACCENTS } from '../theme/theme';
import { expo } from '../../app.json';

export default function SettingsScreen({ navigation }) {
  const { colors, settings, updateSettings, resetSettings } = useTheme();
  const styles = useStyles(makeStyles);
  const { deleteAccount } = useAuth();
  const { removeForUser } = useAppointments();

  const confirmDelete = () =>
    Alert.alert('Delete account?', 'This permanently removes your account and all of your appointments from this device.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => removeForUser(deleteAccount()) },
    ]);

  return (
    <Screen edges={['top', 'bottom']}>
      <Header title="Settings" onBack={() => navigation.goBack()} />

      <SectionTitle>Theme</SectionTitle>
      <Segmented
        value={settings.mode}
        onChange={(mode) => updateSettings({ mode })}
        options={[{ value: 'system', label: 'System' }, { value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }]}
      />

      <SectionTitle>Accent colour</SectionTitle>
      <View style={styles.swatches}>
        {Object.entries(ACCENTS).map(([key, a]) => (
          <TouchableOpacity key={key} onPress={() => updateSettings({ accent: key })} accessibilityLabel={`${a.label} accent`} style={styles.swatchWrap}>
            <View style={[styles.swatch, { backgroundColor: a.main }, settings.accent === key && styles.swatchOn]}>
              {settings.accent === key ? <Ionicons name="checkmark" size={20} color="#fff" /> : null}
            </View>
            <Text style={styles.swatchLabel}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <SectionTitle>Text size</SectionTitle>
      <Segmented
        value={settings.fontSize}
        onChange={(fontSize) => updateSettings({ fontSize })}
        options={[{ value: 'small', label: 'Small' }, { value: 'medium', label: 'Medium' }, { value: 'large', label: 'Large' }]}
      />
      <Card style={{ marginTop: 12 }}>
        <Text style={styles.previewTitle}>Preview</Text>
        <Text style={styles.previewBody}>Brush twice a day and visit your dentist every six months.</Text>
      </Card>
      <TouchableOpacity onPress={resetSettings} style={styles.reset}>
        <Text style={styles.resetText}>Reset appearance to defaults</Text>
      </TouchableOpacity>

      <SectionTitle>Account</SectionTitle>
      <Card>
        <Row icon="person-outline" label="Edit profile" onPress={() => navigation.navigate('EditProfile')} />
        <Row icon="lock-closed-outline" label="Change password" onPress={() => navigation.navigate('ChangePassword')} />
        <Row icon="trash-outline" label="Delete account" onPress={confirmDelete} danger last />
      </Card>

      <Text style={styles.version}>{expo.name} · v{expo.version}</Text>
    </Screen>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    swatches: { flexDirection: 'row', justifyContent: 'space-between' },
    swatchWrap: { alignItems: 'center', gap: 6 },
    swatch: { width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: 'transparent' },
    swatchOn: { borderColor: colors.card, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 6, shadowOffset: { width: 0, height: 2 }, elevation: 4 },
    swatchLabel: { ...typography.caption, fontSize: fs(12) },
    previewTitle: { ...typography.h3, color: colors.primary },
    previewBody: { ...typography.body, marginTop: 4 },
    reset: { alignSelf: 'center', paddingVertical: spacing.sm },
    resetText: { color: colors.primary, fontWeight: '600', fontSize: fs(13) },
    version: { ...typography.caption, textAlign: 'center', marginTop: spacing.lg },
  });
