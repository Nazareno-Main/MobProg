import React from 'react';
import { View, Text, StyleSheet, Alert, Linking } from 'react-native';
import { Screen, Header, Card, Avatar, Row } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useAppointments } from '../context/AppointmentsContext';
import { useStyles } from '../context/ThemeContext';
import { CLINIC } from '../data/clinic';

export default function ProfileScreen({ navigation }) {
  const styles = useStyles(makeStyles);
  const { user, logout } = useAuth();
  const { upcoming, past, cancelled } = useAppointments();

  const confirmLogout = () =>
    Alert.alert('Log out?', 'You can log back in any time.', [
      { text: 'Stay', style: 'cancel' },
      { text: 'Log out', style: 'destructive', onPress: logout },
    ]);

  return (
    <Screen>
      <Header title="Profile" />
      <View style={styles.hero}>
        <Avatar user={user} size={84} />
        <Text style={styles.name}>{user.firstName} {user.lastName}</Text>
        <Text style={styles.sub}>{user.email}</Text>
        <Text style={styles.sub}>{user.phone}</Text>
      </View>

      <View style={styles.stats}>
        {[['Upcoming', upcoming.length], ['Completed', past.length], ['Cancelled', cancelled.length]].map(([label, n]) => (
          <Card key={label} style={styles.stat}>
            <Text style={styles.statNum}>{n}</Text>
            <Text style={styles.sub}>{label}</Text>
          </Card>
        ))}
      </View>

      <Card>
        <Row icon="person-outline" label="Edit profile" onPress={() => navigation.navigate('EditProfile')} />
        <Row icon="color-palette-outline" label="Appearance & settings" onPress={() => navigation.navigate('Settings')} />
        <Row icon="lock-closed-outline" label="Change password" onPress={() => navigation.navigate('ChangePassword')} />
        <Row icon="call-outline" label="Contact clinic" value={CLINIC.phoneLabel} onPress={() => Linking.openURL(`tel:${CLINIC.phone}`)} />
        <Row icon="log-out-outline" label="Log out" onPress={confirmLogout} danger last />
      </Card>
    </Screen>
  );
}

const makeStyles = ({ colors, typography, spacing }) =>
  StyleSheet.create({
    hero: { alignItems: 'center', marginBottom: spacing.lg },
    name: { ...typography.h1, marginTop: spacing.md },
    sub: { ...typography.caption },
    stats: { flexDirection: 'row', gap: spacing.sm },
    stat: { flex: 1, alignItems: 'center', paddingVertical: spacing.md, paddingHorizontal: spacing.sm },
    statNum: { ...typography.h1, color: colors.primary },
  });
