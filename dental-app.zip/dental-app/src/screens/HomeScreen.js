import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, SectionTitle, Avatar } from '../components/ui';
import AppointmentCard from '../components/AppointmentCard';
import AppButton from '../components/AppButton';
import { useAuth } from '../context/AuthContext';
import { useAppointments } from '../context/AppointmentsContext';
import { useStyles, useTheme } from '../context/ThemeContext';
import { CLINIC, SERVICES, TIPS, peso } from '../data/clinic';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
};

export default function HomeScreen({ navigation }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  const { user } = useAuth();
  const { upcoming, cancel } = useAppointments();
  const next = upcoming[0];
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  const tip = TIPS[dayOfYear % TIPS.length];

  const actions = [
    { icon: 'calendar-outline', label: 'Book', onPress: () => navigation.navigate('Book', {}) },
    { icon: 'list-outline', label: 'My visits', onPress: () => navigation.navigate('Appointments') },
    { icon: 'call-outline', label: 'Call us', onPress: () => Linking.openURL(`tel:${CLINIC.phone}`) },
  ];

  return (
    <Screen>
      <View style={styles.top}>
        <View style={{ flex: 1 }}>
          <Text style={styles.hello}>{greeting()},</Text>
          <Text style={styles.name} numberOfLines={1}>{user.firstName} 👋</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')} accessibilityLabel="Open profile">
          <Avatar user={user} />
        </TouchableOpacity>
      </View>

      <SectionTitle>Next appointment</SectionTitle>
      {next ? (
        <AppointmentCard appt={next} onReschedule={(a) => navigation.navigate('Book', { appointmentId: a.id })} onCancel={(a) => cancel(a.id)} />
      ) : (
        <Card>
          <Text style={styles.emptyTitle}>No upcoming visits</Text>
          <Text style={styles.emptyMsg}>Book a check-up and keep your smile healthy.</Text>
          <AppButton title="Book appointment" onPress={() => navigation.navigate('Book', {})} icon={<Ionicons name="add" size={20} color={colors.white} />} />
        </Card>
      )}

      <View style={styles.actions}>
        {actions.map((a) => (
          <TouchableOpacity key={a.label} style={styles.action} onPress={a.onPress} activeOpacity={0.8}>
            <View style={styles.actionIcon}>
              <Ionicons name={a.icon} size={22} color={colors.primary} />
            </View>
            <Text style={styles.actionLabel}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Card style={styles.tip}>
        <Ionicons name="bulb-outline" size={24} color={colors.primary} />
        <View style={{ flex: 1 }}>
          <Text style={styles.tipTitle}>Tip of the day</Text>
          <Text style={styles.tipText}>{tip}</Text>
        </View>
      </Card>

      <SectionTitle action="See all" onAction={() => navigation.navigate('Services')}>Popular services</SectionTitle>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -24 }} contentContainerStyle={{ paddingHorizontal: 24, gap: 12 }}>
        {SERVICES.slice(0, 4).map((s) => (
          <TouchableOpacity key={s.id} style={styles.service} activeOpacity={0.8} onPress={() => navigation.navigate('Book', { serviceId: s.id })}>
            <Ionicons name={s.icon} size={24} color={colors.primary} />
            <Text style={styles.serviceName} numberOfLines={2}>{s.name}</Text>
            <Text style={styles.servicePrice}>from {peso(s.price)}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <SectionTitle>Visit us</SectionTitle>
      <Card>
        <InfoLine icon="location-outline" text={CLINIC.address} />
        <InfoLine icon="time-outline" text={CLINIC.hours} />
        <InfoLine icon="call-outline" text={CLINIC.phoneLabel} onPress={() => Linking.openURL(`tel:${CLINIC.phone}`)} last />
      </Card>
    </Screen>
  );
}

function InfoLine({ icon, text, onPress, last }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);
  return (
    <TouchableOpacity disabled={!onPress} onPress={onPress} style={[styles.info, !last && { marginBottom: 12 }]}>
      <Ionicons name={icon} size={18} color={colors.primary} />
      <Text style={[styles.infoText, onPress && { color: colors.primary }]}>{text}</Text>
    </TouchableOpacity>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    top: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.md },
    hello: { ...typography.body, color: colors.textMuted },
    name: { ...typography.h1 },
    emptyTitle: { ...typography.h3 },
    emptyMsg: { ...typography.caption, marginTop: 4, marginBottom: spacing.md },
    actions: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.md },
    action: { flex: 1, alignItems: 'center', backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, paddingVertical: spacing.md },
    actionIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
    actionLabel: { fontSize: fs(13), fontWeight: '600', color: colors.text },
    tip: { flexDirection: 'row', gap: spacing.md, alignItems: 'flex-start', backgroundColor: colors.primaryLight, borderColor: 'transparent' },
    tipTitle: { ...typography.h3, color: colors.primary },
    tipText: { ...typography.body, marginTop: 2 },
    service: { width: 140, backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md },
    serviceName: { ...typography.h3, marginTop: spacing.sm, minHeight: fs(40) },
    servicePrice: { ...typography.caption, marginTop: 4 },
    info: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
    infoText: { ...typography.body, flex: 1 },
  });
