import React, { useState } from 'react';
import { Alert } from 'react-native';
import { Screen, Header } from '../components/ui';
import InputField from '../components/InputField';
import AppButton from '../components/AppButton';
import { useAuth } from '../context/AuthContext';

export default function ChangePasswordScreen({ navigation }) {
  const { changePassword } = useAuth();
  const [form, setForm] = useState({ current: '', next: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    const e = {};
    if (!form.current) e.current = 'Enter your current password';
    if (form.next.length < 6) e.next = 'At least 6 characters';
    if (form.confirm !== form.next) e.confirm = 'Passwords do not match';
    setErrors(e);
    if (Object.keys(e).length) return;

    setLoading(true);
    const res = await changePassword(form.current, form.next);
    setLoading(false);
    if (!res.ok) return setErrors({ current: res.error });
    Alert.alert('Password changed', 'Use your new password next time you log in.', [{ text: 'OK', onPress: () => navigation.goBack() }]);
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <Header title="Change Password" onBack={() => navigation.goBack()} />
      <InputField label="Current password" icon="lock-closed-outline" isPassword value={form.current} onChangeText={set('current')} error={errors.current} />
      <InputField label="New password" icon="key-outline" isPassword value={form.next} onChangeText={set('next')} error={errors.next} placeholder="At least 6 characters" />
      <InputField label="Confirm new password" icon="key-outline" isPassword value={form.confirm} onChangeText={set('confirm')} error={errors.confirm} />
      <AppButton title="Update Password" onPress={submit} loading={loading} />
    </Screen>
  );
}
