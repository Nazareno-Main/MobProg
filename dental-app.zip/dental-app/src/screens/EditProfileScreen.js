import React, { useState } from 'react';
import { Alert } from 'react-native';
import { Screen, Header } from '../components/ui';
import InputField from '../components/InputField';
import AppButton from '../components/AppButton';
import { useAuth } from '../context/AuthContext';

export default function EditProfileScreen({ navigation }) {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({ firstName: user.firstName, lastName: user.lastName, phone: user.phone });
  const [errors, setErrors] = useState({});
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const save = () => {
    const next = {};
    if (!form.firstName.trim()) next.firstName = 'First name is required';
    if (!form.lastName.trim()) next.lastName = 'Last name is required';
    if (!form.phone.trim()) next.phone = 'Phone number is required';
    setErrors(next);
    if (Object.keys(next).length) return;
    updateProfile(form);
    Alert.alert('Saved', 'Your profile has been updated.', [{ text: 'OK', onPress: () => navigation.goBack() }]);
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <Header title="Edit Profile" onBack={() => navigation.goBack()} />
      <InputField label="First Name" icon="person-outline" value={form.firstName} onChangeText={set('firstName')} error={errors.firstName} />
      <InputField label="Last Name" icon="person-outline" value={form.lastName} onChangeText={set('lastName')} error={errors.lastName} />
      <InputField label="Phone Number" icon="call-outline" keyboardType="phone-pad" value={form.phone} onChangeText={set('phone')} error={errors.phone} />
      <InputField label="Email (cannot be changed)" icon="mail-outline" value={user.email} editable={false} />
      <AppButton title="Save Changes" onPress={save} />
    </Screen>
  );
}
