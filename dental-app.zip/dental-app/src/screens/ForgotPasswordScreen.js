import React, { useState } from 'react';
import { Text, StyleSheet, Alert } from 'react-native';
import InputField from '../components/InputField';
import AppButton from '../components/AppButton';
import { Screen, Header } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useStyles } from '../context/ThemeContext';

export default function ForgotPasswordScreen({ navigation }) {
  const styles = useStyles(makeStyles);
  const { accountExists, resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [verified, setVerified] = useState(false);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const verify = () => {
    if (!accountExists(email)) return setError('No account found with that email');
    setError('');
    setVerified(true);
  };

  const submit = async () => {
    if (password.length < 6) return setError('Password must be at least 6 characters');
    if (password !== confirm) return setError('Passwords do not match');
    setLoading(true);
    const res = await resetPassword(email, password);
    setLoading(false);
    if (!res.ok) return setError(res.error);
    Alert.alert('Password updated', 'You can now log in with your new password.', [{ text: 'OK', onPress: () => navigation.goBack() }]);
  };

  return (
    <Screen>
      <Header title="Reset Password" onBack={() => navigation.goBack()} />
      <Text style={styles.sub}>
        {verified ? 'Choose a new password for your account.' : 'Enter the email linked to your account.'}
      </Text>
      <Text style={styles.note}>Demo mode: there is no email server, so the reset happens directly on this device.</Text>

      <InputField icon="mail-outline" placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={(t) => { setEmail(t); setVerified(false); setError(''); }} editable={!verified} />

      {verified ? (
        <>
          <InputField label="New password" icon="lock-closed-outline" isPassword value={password} onChangeText={setPassword} placeholder="At least 6 characters" />
          <InputField label="Confirm new password" icon="lock-closed-outline" isPassword value={confirm} onChangeText={setConfirm} placeholder="Re-enter password" />
        </>
      ) : null}

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <AppButton title={verified ? 'Update Password' : 'Continue'} onPress={verified ? submit : verify} loading={loading} disabled={!email.trim()} />
    </Screen>
  );
}

const makeStyles = ({ colors, typography, spacing, fs }) =>
  StyleSheet.create({
    sub: { ...typography.body, color: colors.textMuted },
    note: { ...typography.caption, marginTop: spacing.sm, marginBottom: spacing.lg },
    error: { color: colors.danger, fontSize: fs(13), marginBottom: spacing.md },
  });
