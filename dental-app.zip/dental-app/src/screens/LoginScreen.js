import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import BrandHeader from '../components/BrandHeader';
import InputField from '../components/InputField';
import AppButton from '../components/AppButton';
import { Screen } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useStyles } from '../context/ThemeContext';
import { CLINIC } from '../data/clinic';

export default function LoginScreen({ navigation }) {
  const styles = useStyles(makeStyles);
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    const next = {};
    if (!email.trim()) next.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) next.email = 'Enter a valid email';
    if (!password) next.password = 'Password is required';
    setErrors(next);
    if (Object.keys(next).length) return;

    setLoading(true);
    const res = await login(email, password);
    setLoading(false);
    if (!res.ok) setErrors({ password: res.error });
    // On success the navigator swaps to the signed-in screens automatically.
  };

  return (
    <Screen edges={['top', 'bottom']} contentStyle={{ paddingTop: 48 }}>
      <BrandHeader title="Welcome Back" subtitle={`Sign in to manage your ${CLINIC.name} appointments`} />

      <InputField label="Email" icon="mail-outline" placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} value={email} onChangeText={setEmail} error={errors.email} />
      <InputField label="Password" icon="lock-closed-outline" placeholder="Enter your password" isPassword value={password} onChangeText={setPassword} error={errors.password} onSubmitEditing={handleLogin} />

      <TouchableOpacity style={styles.forgot} onPress={() => navigation.navigate('ForgotPassword')}>
        <Text style={styles.forgotText}>Forgot Password?</Text>
      </TouchableOpacity>

      <AppButton title="Log In" onPress={handleLogin} loading={loading} />

      <TouchableOpacity style={styles.demo} onPress={() => { setEmail('admin@demo.com'); setPassword('admin123'); setErrors({}); }}>
        <Text style={styles.demoText}>Demo account: admin@demo.com / admin123 (tap to fill)</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Don't have an account? </Text>
        <TouchableOpacity onPress={() => navigation.navigate('Register')}>
          <Text style={styles.footerLink}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </Screen>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    forgot: { alignSelf: 'flex-end', marginBottom: spacing.lg },
    forgotText: { color: colors.primary, fontWeight: '600', fontSize: fs(13) },
    demo: { marginTop: spacing.lg, padding: spacing.md, borderRadius: radius.md, backgroundColor: colors.primaryLight },
    demoText: { color: colors.primary, textAlign: 'center', fontSize: fs(13), fontWeight: '600' },
    footer: { flexDirection: 'row', justifyContent: 'center', marginTop: spacing.lg },
    footerText: { ...typography.body, color: colors.textMuted },
    footerLink: { ...typography.body, color: colors.primary, fontWeight: '700' },
  });
