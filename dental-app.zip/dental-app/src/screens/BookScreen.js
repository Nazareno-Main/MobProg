import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Screen, Header, Chip, Card, SectionTitle } from '../components/ui';
import InputField from '../components/InputField';
import AppButton from '../components/AppButton';
import { useAppointments } from '../context/AppointmentsContext';
import { useStyles } from '../context/ThemeContext';
import { DENTISTS, SERVICES, TIME_SLOTS, getDentist, getService, peso } from '../data/clinic';
import { bookableDays, formatDate, formatTime, toDateTime } from '../utils/date';

export default function BookScreen({ navigation, route }) {
  const styles = useStyles(makeStyles);
  const appts = useAppointments();
  const editing = route.params?.appointmentId ? appts.find(route.params.appointmentId) : null;

  const [serviceId, setServiceId] = useState(editing?.serviceId || route.params?.serviceId || null);
  const [dentistId, setDentistId] = useState(editing?.dentistId || null);
  const [date, setDate] = useState(editing?.date || null);
  const [time, setTime] = useState(editing?.time || null);
  const [notes, setNotes] = useState(editing?.notes || '');

  const days = useMemo(() => bookableDays(14), []);
  const dentists = DENTISTS.filter((d) => serviceId && d.serviceIds.includes(serviceId));
  const service = serviceId && getService(serviceId);
  const ready = serviceId && dentistId && date && time;

  const pickService = (id) => {
    setServiceId(id);
    const stillValid = getDentist(dentistId)?.serviceIds.includes(id);
    if (!stillValid) setDentistId(null);
    setTime(null);
  };

  const slotDisabled = (t) =>
    !date || toDateTime(date, t) <= new Date() || !dentistId || appts.isTaken(dentistId, date, t, editing?.id);

  const confirm = () => {
    const data = { serviceId, dentistId, date, time, notes: notes.trim() };
    if (editing) appts.update(editing.id, data);
    else appts.book(data);
    Alert.alert(editing ? 'Appointment rescheduled' : 'Appointment booked', `${service.name}\n${formatDate(date)} at ${formatTime(time)}`, [
      { text: 'OK', onPress: () => navigation.navigate('Tabs', { screen: 'Appointments' }) },
    ]);
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <Header title={editing ? 'Reschedule' : 'Book Visit'} onBack={() => navigation.goBack()} />

      <SectionTitle>1. Service</SectionTitle>
      <View style={styles.wrap}>
        {SERVICES.map((s) => (
          <Chip key={s.id} label={s.name} icon={s.icon} selected={serviceId === s.id} onPress={() => pickService(s.id)} disabled={!!editing && serviceId !== s.id} />
        ))}
      </View>

      <SectionTitle>2. Dentist</SectionTitle>
      {!serviceId ? (
        <Text style={styles.hint}>Choose a service first.</Text>
      ) : (
        dentists.map((d) => (
          <Card key={d.id} onPress={() => { setDentistId(d.id); setTime(null); }} style={[styles.dentist, dentistId === d.id && styles.dentistOn]}>
            <Text style={styles.dentistName}>{d.name}</Text>
            <Text style={styles.hint}>{d.specialty}</Text>
          </Card>
        ))
      )}

      <SectionTitle>3. Date</SectionTitle>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -24 }} contentContainerStyle={{ paddingHorizontal: 24, gap: 10 }}>
        {days.map((d) => (
          <TouchableOpacity key={d.iso} onPress={() => { setDate(d.iso); setTime(null); }} style={[styles.day, date === d.iso && styles.dayOn]} activeOpacity={0.8}>
            <Text style={[styles.dayDow, date === d.iso && styles.dayTextOn]}>{d.dow}</Text>
            <Text style={[styles.dayNum, date === d.iso && styles.dayTextOn]}>{d.day}</Text>
            <Text style={[styles.dayDow, date === d.iso && styles.dayTextOn]}>{d.month}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <SectionTitle>4. Time</SectionTitle>
      {!dentistId || !date ? (
        <Text style={styles.hint}>Pick a dentist and a date to see open times.</Text>
      ) : (
        <View style={styles.wrap}>
          {TIME_SLOTS.map((t) => (
            <Chip key={t} label={formatTime(t)} selected={time === t} disabled={slotDisabled(t)} onPress={() => setTime(t)} />
          ))}
        </View>
      )}

      <SectionTitle>Notes (optional)</SectionTitle>
      <InputField placeholder="Anything the dentist should know? e.g. tooth sensitivity" value={notes} onChangeText={setNotes} multiline maxLength={200} />

      {ready ? (
        <Card style={styles.summary}>
          <Text style={styles.summaryTitle}>{service.name}</Text>
          <Text style={styles.summaryLine}>{getDentist(dentistId).name}</Text>
          <Text style={styles.summaryLine}>{formatDate(date)} · {formatTime(time)}</Text>
          <Text style={styles.summaryLine}>{service.minutes} min · from {peso(service.price)}</Text>
        </Card>
      ) : null}

      <AppButton title={editing ? 'Save New Time' : 'Confirm Booking'} onPress={confirm} disabled={!ready} />
    </Screen>
  );
}

const makeStyles = ({ colors, typography, radius, spacing, fs }) =>
  StyleSheet.create({
    wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
    hint: { ...typography.caption },
    dentist: { marginBottom: spacing.sm, borderWidth: 1.5 },
    dentistOn: { borderColor: colors.primary, backgroundColor: colors.primaryLight },
    dentistName: { ...typography.h3 },
    day: { width: 64, alignItems: 'center', paddingVertical: 12, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.card },
    dayOn: { backgroundColor: colors.primary, borderColor: colors.primary },
    dayDow: { fontSize: fs(12), color: colors.textMuted, fontWeight: '600' },
    dayNum: { fontSize: fs(20), fontWeight: '700', color: colors.text, marginVertical: 2 },
    dayTextOn: { color: colors.white },
    summary: { marginTop: spacing.md, backgroundColor: colors.primaryLight, borderColor: 'transparent' },
    summaryTitle: { ...typography.h3, color: colors.primary, marginBottom: 4 },
    summaryLine: { ...typography.body },
  });
