import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Header, Card, SectionTitle, Avatar } from '../components/ui';
import AppButton from '../components/AppButton';
import { useStyles, useTheme } from '../context/ThemeContext';
import { DENTISTS, SERVICES, peso } from '../data/clinic';

export default function ServicesScreen({ navigation }) {
  const { colors } = useTheme();
  const styles = useStyles(makeStyles);

  return (
    <Screen>
      <Header title="Services" />
      {SERVICES.map((s) => (
        <Card key={s.id}>
          <View style={styles.row}>
            <View style={styles.icon}>
              <Ionicons name={s.icon} size={22} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{s.name}</Text>
              <Text style={styles.caption}>{s.minutes} min · from {peso(s.price)}</Text>
            </View>
          </View>
          <Text style={styles.about}>{s.about}</Text>
          <AppButton title="Book this" variant="outline" onPress={() => navigation.navigate('Book', { serviceId: s.id })} style={{ height: 44 }} />
        </Card>
      ))}

      <SectionTitle>Our dentists</SectionTitle>
      {DENTISTS.map((d) => (
        <Card key={d.id} style={styles.row}>
          <Avatar user={{ firstName: d.name.split(' ')[1], lastName: d.name.split(' ')[2] }} />
          <View style={{ flex: 1 }}>
            <Text style={styles.name}>{d.name}</Text>
            <Text style={styles.caption}>{d.specialty}</Text>
          </View>
        </Card>
      ))}
      <Text style={styles.caption}>Prices are estimates and may vary after your dentist's assessment.</Text>
    </Screen>
  );
}

const makeStyles = ({ colors, typography, radius, spacing }) =>
  StyleSheet.create({
    row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
    icon: { width: 44, height: 44, borderRadius: radius.md, backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center' },
    name: { ...typography.h3 },
    caption: { ...typography.caption },
    about: { ...typography.body, marginVertical: spacing.md },
  });
