// Theme engine: light / dark / system, 5 accent colours and 3 text sizes.
export const ACCENTS = {
  teal: { label: 'Teal', main: '#2A9D8F', dark: '#21807A', light: '#E6F5F3' },
  blue: { label: 'Ocean', main: '#2F80ED', dark: '#1F63BF', light: '#E7F0FD' },
  purple: { label: 'Violet', main: '#7C5CFC', dark: '#5E42D1', light: '#EFEBFF' },
  rose: { label: 'Rose', main: '#E5527A', dark: '#C13A60', light: '#FCE9EF' },
  orange: { label: 'Sunset', main: '#E67E22', dark: '#C0651A', light: '#FEF0E0' },
};

export const FONT_SCALES = { small: 0.9, medium: 1, large: 1.15 };

export const DEFAULT_SETTINGS = { mode: 'system', accent: 'teal', fontSize: 'medium' };

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 };
export const radius = { sm: 8, md: 12, lg: 16, pill: 999 };

const LIGHT = {
  background: '#FFFFFF',
  surface: '#F5FBFA',
  card: '#FFFFFF',
  border: '#E1E8E7',
  text: '#1F2937',
  textMuted: '#6B7280',
  placeholder: '#9CA3AF',
  secondary: '#264653',
};

const DARK = {
  background: '#0F1517',
  surface: '#182024',
  card: '#1B262B',
  border: '#2A373D',
  text: '#F1F5F5',
  textMuted: '#9AA9AE',
  placeholder: '#6B7C82',
  secondary: '#D6E8E6',
};

export function buildTheme(settings, systemScheme) {
  const { mode, accent, fontSize } = { ...DEFAULT_SETTINGS, ...settings };
  const isDark = mode === 'dark' || (mode === 'system' && systemScheme === 'dark');
  const a = ACCENTS[accent] || ACCENTS.teal;
  const scale = FONT_SCALES[fontSize] || 1;
  const fs = (n) => Math.round(n * scale);

  const colors = {
    ...(isDark ? DARK : LIGHT),
    primary: a.main,
    primaryDark: a.dark,
    primaryLight: isDark ? `${a.main}2E` : a.light,
    danger: '#E76F51',
    success: '#2E9E6B',
    white: '#FFFFFF',
  };

  const typography = {
    h1: { fontSize: fs(28), fontWeight: '700', color: colors.secondary },
    h2: { fontSize: fs(20), fontWeight: '600', color: colors.secondary },
    h3: { fontSize: fs(16), fontWeight: '600', color: colors.text },
    body: { fontSize: fs(15), fontWeight: '400', color: colors.text },
    caption: { fontSize: fs(13), fontWeight: '400', color: colors.textMuted },
    button: { fontSize: fs(16), fontWeight: '600' },
  };

  return { isDark, colors, typography, fs, spacing, radius };
}
