import AsyncStorage from '@react-native-async-storage/async-storage';

export const KEYS = {
  settings: '@dental/settings',
  users: '@dental/users',
  session: '@dental/session',
  appointments: '@dental/appointments',
};

export async function load(key, fallback) {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export async function save(key, value) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage is best-effort; the in-memory state still works
  }
}
