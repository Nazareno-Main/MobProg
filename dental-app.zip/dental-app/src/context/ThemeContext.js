import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { buildTheme, DEFAULT_SETTINGS } from '../theme/theme';
import { KEYS, load, save } from '../utils/storage';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const system = useColorScheme();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    load(KEYS.settings, {}).then((saved) => {
      setSettings({ ...DEFAULT_SETTINGS, ...saved });
      setReady(true);
    });
  }, []);

  const updateSettings = useCallback((patch) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      save(KEYS.settings, next);
      return next;
    });
  }, []);

  const resetSettings = useCallback(() => updateSettings(DEFAULT_SETTINGS), [updateSettings]);

  const theme = useMemo(() => buildTheme(settings, system), [settings, system]);
  const value = useMemo(
    () => ({ ...theme, settings, updateSettings, resetSettings }),
    [theme, settings, updateSettings, resetSettings],
  );

  if (!ready) return null;
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);

// const styles = useStyles((t) => StyleSheet.create({ ... }))
export function useStyles(factory) {
  const theme = useTheme();
  return useMemo(() => factory(theme), [theme]); // eslint-disable-line react-hooks/exhaustive-deps
}
