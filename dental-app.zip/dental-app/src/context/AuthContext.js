import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import * as Crypto from 'expo-crypto';
import { KEYS, load, save } from '../utils/storage';

const AuthContext = createContext(null);

const hash = (salt, password) =>
  Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, `${salt}:${password}`);

async function makeUser({ firstName, lastName, email, phone, password }) {
  const salt = Crypto.randomUUID();
  return {
    id: Crypto.randomUUID(),
    firstName: firstName.trim(),
    lastName: lastName.trim(),
    email: email.trim().toLowerCase(),
    phone: phone.trim(),
    salt,
    passwordHash: await hash(salt, password),
    createdAt: new Date().toISOString(),
  };
}

// Demo accounts, created on first launch (same logins as the original app).
const DEMO_USERS = [
  { firstName: 'Admin', lastName: 'User', email: 'admin@demo.com', phone: '0917 000 0001', password: 'admin123' },
  { firstName: 'Manager', lastName: 'User', email: 'manager@demo.com', phone: '0917 000 0002', password: 'manager123' },
];

export function AuthProvider({ children }) {
  const [users, setUsers] = useState([]);
  const [currentId, setCurrentId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      let stored = await load(KEYS.users, null);
      if (!stored) {
        stored = await Promise.all(DEMO_USERS.map(makeUser));
        await save(KEYS.users, stored);
      }
      setUsers(stored);
      setCurrentId(await load(KEYS.session, null));
      setLoading(false);
    })();
  }, []);

  const value = useMemo(() => {
    const user = users.find((u) => u.id === currentId) || null;
    const commit = (next) => {
      setUsers(next);
      save(KEYS.users, next);
    };
    const signIn = (id) => {
      setCurrentId(id);
      save(KEYS.session, id);
    };
    const findByEmail = (email) => users.find((u) => u.email === email.trim().toLowerCase());
    const patchUser = (id, patch) => commit(users.map((u) => (u.id === id ? { ...u, ...patch } : u)));

    return {
      user,
      loading,

      async login(email, password) {
        const found = findByEmail(email);
        if (!found || (await hash(found.salt, password)) !== found.passwordHash) {
          return { ok: false, error: 'Incorrect email or password' };
        }
        signIn(found.id);
        return { ok: true };
      },

      async register(form) {
        if (findByEmail(form.email)) {
          return { ok: false, field: 'email', error: 'An account with this email already exists' };
        }
        const created = await makeUser(form);
        commit([...users, created]);
        signIn(created.id);
        return { ok: true };
      },

      logout() {
        setCurrentId(null);
        save(KEYS.session, null);
      },

      updateProfile(patch) {
        patchUser(user.id, {
          firstName: patch.firstName.trim(),
          lastName: patch.lastName.trim(),
          phone: patch.phone.trim(),
        });
      },

      async changePassword(current, next) {
        if ((await hash(user.salt, current)) !== user.passwordHash) {
          return { ok: false, error: 'Current password is incorrect' };
        }
        const salt = Crypto.randomUUID();
        patchUser(user.id, { salt, passwordHash: await hash(salt, next) });
        return { ok: true };
      },

      // Demo flow: with no backend there is no email to send, so the reset happens on-device.
      accountExists: (email) => !!findByEmail(email),
      async resetPassword(email, next) {
        const found = findByEmail(email);
        if (!found) return { ok: false, error: 'No account found with that email' };
        const salt = Crypto.randomUUID();
        patchUser(found.id, { salt, passwordHash: await hash(salt, next) });
        return { ok: true };
      },

      deleteAccount() {
        const id = user.id;
        setCurrentId(null);
        save(KEYS.session, null);
        commit(users.filter((u) => u.id !== id));
        return id;
      },
    };
  }, [users, currentId, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
