import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import * as Crypto from 'expo-crypto';
import { useAuth } from './AuthContext';
import { KEYS, load, save } from '../utils/storage';
import { toDateTime } from '../utils/date';

const AppointmentsContext = createContext(null);

export function AppointmentsProvider({ children }) {
  const { user } = useAuth();
  const [items, setItems] = useState([]);

  useEffect(() => {
    load(KEYS.appointments, []).then(setItems);
  }, []);

  const value = useMemo(() => {
    const commit = (next) => {
      setItems(next);
      save(KEYS.appointments, next);
    };
    const now = new Date();
    const mine = items
      .filter((a) => a.userId === user?.id)
      .sort((a, b) => toDateTime(a.date, a.time) - toDateTime(b.date, b.time));

    return {
      upcoming: mine.filter((a) => a.status === 'booked' && toDateTime(a.date, a.time) >= now),
      past: mine.filter((a) => a.status === 'booked' && toDateTime(a.date, a.time) < now).reverse(),
      cancelled: mine.filter((a) => a.status === 'cancelled').reverse(),
      find: (id) => items.find((a) => a.id === id),

      // A slot is taken when the same dentist already has an active booking at that time.
      isTaken: (dentistId, date, time, ignoreId) =>
        items.some(
          (a) => a.status === 'booked' && a.dentistId === dentistId && a.date === date && a.time === time && a.id !== ignoreId,
        ),

      book(data) {
        commit([...items, { ...data, id: Crypto.randomUUID(), userId: user.id, status: 'booked', createdAt: new Date().toISOString() }]);
      },
      update(id, patch) {
        commit(items.map((a) => (a.id === id ? { ...a, ...patch } : a)));
      },
      cancel(id) {
        commit(items.map((a) => (a.id === id ? { ...a, status: 'cancelled' } : a)));
      },
      removeForUser(userId) {
        commit(items.filter((a) => a.userId !== userId));
      },
    };
  }, [items, user]);

  return <AppointmentsContext.Provider value={value}>{children}</AppointmentsContext.Provider>;
}

export const useAppointments = () => useContext(AppointmentsContext);
